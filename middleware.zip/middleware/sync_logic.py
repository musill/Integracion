# sync_logic.py
from api_clients import api_sqlite, api_mysql
from utils import select_primary_source

def sync_estudiantes():
    sqlite_data = api_sqlite.get_all_estudiantes()
    mysql_data = api_mysql.get_all_estudiantes()
    final_data = select_primary_source(sqlite_data, mysql_data)
    for est in final_data:
        if est not in sqlite_data:
            api_sqlite.create_estudiante(est)
        if est not in mysql_data:
            api_mysql.create_estudiante(est)

def sync_profesores():
    sqlite_data = api_sqlite.get_all_profesores()
    mysql_data = api_mysql.get_all_profesores()
    final_data = select_primary_source(sqlite_data, mysql_data)
    for prof in final_data:
        if prof not in sqlite_data:
            api_sqlite.create_profesor(prof)
        if prof not in mysql_data:
            api_mysql.create_profesor(prof)

def sync_asignaturas():
    sqlite_data = api_sqlite.get_all_asignaturas()
    mysql_data = api_mysql.get_all_asignaturas()
    final_data = select_primary_source(sqlite_data, mysql_data)
    for asig in final_data:
        if asig not in sqlite_data:
            api_sqlite.create_asignatura(asig)
        if asig not in mysql_data:
            api_mysql.create_asignatura(asig)

def sync_matricula():
    sqlite_data = api_sqlite.get_all_matricula()
    mysql_data = api_mysql.get_all_matricula()
    final_data = select_primary_source(sqlite_data, mysql_data)
    for mat in final_data:
        if mat not in sqlite_data:
            api_sqlite.create_matricula(mat)
        if mat not in mysql_data:
            api_mysql.create_matricula(mat)

def sync_profeciclo():
    sqlite_data = api_sqlite.get_all_profeciclo()
    mysql_data = api_mysql.get_all_profeciclo()
    final_data = select_primary_source(sqlite_data, mysql_data)
    for pc in final_data:
        if pc not in sqlite_data:
            api_sqlite.create_profeciclo(pc)
        if pc not in mysql_data:
            api_mysql.create_profeciclo(pc)

def sync_all():
    sync_estudiantes()
    sync_profesores()
    sync_asignaturas()
    sync_matricula()
    sync_profeciclo()
